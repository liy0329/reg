using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FastReport;

namespace DataFromArray
{
  public partial class Form1 : Form
  {
    private int[] FArray;
    private string [] sArray=new string[10];
    
    public Form1()
    {
      InitializeComponent();
      CreateArray();
    }

    private void CreateArray()
    {
      FArray = new int[10];
      for (int i = 0; i < 10; i++)
      {
            FArray[i] = i + 1;
            sArray[i] = "a_x" + i.ToString();
      }
    }

    private void btnCreateNew_Click(object sender, EventArgs e)
    {
      // create report instance
      Report report = new Report();

      // register the array
      report.RegisterData(FArray, "Array");

      // design the report
      report.Design();

      // free resources used by report
      report.Dispose();
    }

    private void btnRunExisting_Click(object sender, EventArgs e)
    {
      // create report instance
      Report report = new Report();

      // load the existing report
      string ff = (@"..\..\report.frx");
      report.Load(@"..\..\report.frx");

      FastReport.ObjectCollection aList = new ObjectCollection();
      report.GetChildObjects(aList);

      FastReport.Data.ParameterCollection PaList = report.Parameters;// report.GetParameter("Txt_zhu");

      PageCollection pList = report.Pages;

        //-----
      FastReport.ObjectCollection OList = report.AllObjects;//ȡ������Report�еĶ���
      foreach (object a in OList)
      {
          string aType = a.GetType().ToString();
          if (aType == "FastReport.TextObject")
          {
              FastReport.TextObject aTextCtl = (FastReport.TextObject)a;
              Console.WriteLine(aTextCtl.Name);
              if (aTextCtl.Name == "Txt_zhu") 
                  aTextCtl.Text = "�����ҵĴ�ŮText";
          }
      }

      // register the array
      report.RegisterData(sArray, "Array");

      // run the report
      report.Show();

      // free resources used by report
      report.Dispose();
    }
  }
}