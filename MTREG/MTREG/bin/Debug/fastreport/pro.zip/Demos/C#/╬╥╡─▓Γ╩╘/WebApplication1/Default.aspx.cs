﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

using FastReport;
using FastReport.Web;
using FastReport.Export.Pdf;
using FastReport.Export.OoXML;

namespace WebApplication1
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            SetReport_File();
         //   SetReport_Data();
        }


        public void SetReport_File()
        {
            //指定报表文件
            WebReport1.ReportFile = "testReport.frx";
            WebReport1.Prepare();

 
        }

        protected void WebReport1_StartReport(object sender, EventArgs e)
        {
            Report aReport = (sender as WebReport).Report;
            string arname = aReport.ReportInfo.Name;

            //另外一种指定报表文件的方法
           // string rFile = Server.MapPath("~/") + "testReport.frx";
            //aReport.LoadPrepared(rFile);//指定报表文件
            //(sender as WebReport).ReportDone = true;

            

            //报表数据准备
            //1.手工填写
            Set_ReportData_Bymanual(aReport);

//            aReport.Export(new PDFExport(), "E:\\WebApplication1\\WebApplication1\\aa.pdf");


            //2.数据源自动填写
            //   RegisterData(FReport);

            //3.报表代码填写
            //  Labels aLabel = new Labels();
            //  aLabel.Text12.Text = "dddd";

            //            aReport.ShowPrintDialog(true;
           // aReport.ShowPrepared();
           // aReport.Print();
        }

//          如果要套打，就需要在打印输出PDF前，把控件。Visible=false   
//          所以要自己导出PDF到新页面。

        protected void Set_ReportData_Bymanual(Report aReport)
        {
            TextObject aTextCtl;

            //-----
            FastReport.ObjectCollection OList = aReport.AllObjects;//取得所有Report中的对象
            foreach (object a in OList)
            {
                string aType = a.GetType().ToString();
                if (aType == "FastReport.TextObject")
                {
                    aTextCtl = (FastReport.TextObject)a;
                    string aTxt = aTextCtl.Name;
                    if (aTextCtl.Name == "Txt_zhu")
                        aTextCtl.Text = "这是我的处女作";
                }
            }

            //隐藏
           // aTextCtl = aReport.FindObject("Tet_psh") as TextObject;
           // aTextCtl.Visible = false;

            aTextCtl = aReport.FindObject("Txt_zhu") as TextObject;
            aTextCtl.Text = "找到处女作";
        }

        protected void WebReport1_PreRender(object sender, EventArgs e)
        {
            string ff = "aa";
        }



        protected void Export_Report(Report aReport)
        {
            // save file in stream
            Stream stream = new MemoryStream();
            WebReport1.Report.Export(new PDFExport(), stream);
            stream.Position = 0;
            //// return stream in browser
            //FILE (stream, "application/zip", "report.pdf");

          // PDFExport pdfExport = new PDFExport();
            //using (MemoryStream strm = new MemoryStream())
            //{
            //    WebReport1.Report.Export(new PDFExport(), strm);
            //   // aReport.Export(pdfExport, strm);
            //    // Stream the PDF back to the client as an attachment
            //    Response.ClearContent();
            //    Response.ClearHeaders();
            //    Response.Buffer = true;
            //    Response.ContentType = "Application/PDF";
            //    Response.AddHeader("Content-Disposition", "attachment;filename=report.pdf");
            //    strm.Position = 0;
            //    strm.WriteTo(Response.OutputStream);
            //    Response.End();
            //}




        //webReport.Report.Export(new Excel2007Export(), stream);
        //...
        //return File(stream, "application/xlsx", "report.xlsx");

        }
    }
}
